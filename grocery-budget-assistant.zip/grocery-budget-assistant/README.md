# Grocery Budget Assistant

A terminal app that logs grocery purchases, compares them with a fixed budget and
warns you when you are close to (or past) the limit. Built for the Campus Catalyst
hackathon, project #18.

## Features
- Menu-driven terminal interface
- Strict input validation (prices, quantities, dates, categories) with re-prompting
- Budget status: ON TRACK / WARNING (80%+) / OVER BUDGET
- JSON persistence, saved after every change; a corrupted file is backed up, not fatal
- Search by keyword and category
- Summary with totals, averages, category and monthly breakdown, biggest purchases
- Warnings for unusual entries (huge single items, price spikes)
- Matplotlib charts: spending by category and running total vs budget
- Export to `.txt`, `.md` and `.csv`
- CSV import with a row-by-row error log (`reports/import_errors.log`)

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python main.py
```
Python 3.10+ is needed. Everything except charts uses only the standard library.

## Try it quickly
1. Start the app and pick **10** to load 44 sample items.
2. Pick **6** for the summary and warnings.
3. Pick **9** and enter `data/bad_import.csv` to see invalid rows rejected and logged.
4. Pick **7** and **8** to make charts and reports in `reports/`.
5. Exit with **0**, start again, and your data is still there.

## Project layout
```
main.py              menu loop and handlers
grocery/
  models.py          Item dataclass
  validation.py      parse_* checks shared by prompts, storage and importer
  logic.py           budget maths (no input/output)
  storage.py         JSON load/save with recovery
  importer.py        CSV import with error log
  reports.py         summary text and exports
  charts.py          matplotlib charts
  ui.py              printing, tables, prompts
data/                sample_data.json, sample_import.csv, bad_import.csv
tests/test_app.py    unit tests
```

## Tests
```bash
python -m unittest discover -s tests
```

## Notes
- The currency label is `CURRENCY` in `grocery/reports.py`.
- The warning threshold is `WARN_AT` in `grocery/logic.py`.
