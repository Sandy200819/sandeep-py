"""Grocery Budget Assistant - run with:  python main.py"""
import os
import sys
from datetime import date

from grocery import charts, importer, logic, reports, storage, ui
from grocery.models import Item
from grocery.validation import (
    CATEGORIES, BadValue, parse_budget, parse_category, parse_date,
    parse_name, parse_price, parse_quantity,
)

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(ROOT, "data", "grocery_data.json")
SAMPLE_FILE = os.path.join(ROOT, "data", "sample_data.json")
REPORT_DIR = os.path.join(ROOT, "reports")


def current_budget_line(state):
    items = state["items"]
    return ui.budget_line(
        state,
        logic.status(state["budget"], items),
        logic.total_spent(items),
        logic.percent_used(state["budget"], items),
    )


def show_warnings(state, just_added=None):
    """Print any warnings that apply right now."""
    items, budget = state["items"], state["budget"]
    label = logic.status(budget, items)
    if label == "OVER BUDGET":
        over = -logic.remaining(budget, items)
        print(ui.red(f"  !! You are over budget by {reports.money(over)}."))
    elif label == "WARNING":
        print(ui.yellow(f"  ! Careful: {logic.percent_used(budget, items)}% of your budget is already used."))
    if just_added is not None:
        for item, why in logic.find_anomalies(items, budget):
            if item.id == just_added.id:
                print(ui.yellow(f"  ! Unusual entry: {why}."))


def add_item(state):
    print("\nAdd an item (leave a prompt empty only where shown)")
    name = ui.ask("Item name", parse_name)
    print("  Categories: " + ", ".join(CATEGORIES))
    category = ui.ask("Category", parse_category)
    price = ui.ask("Price per unit", parse_price)
    qty = ui.ask("Quantity", parse_quantity, default=1)
    day = ui.ask("Date YYYY-MM-DD", parse_date, default=date.today().isoformat())

    item = Item(storage.next_id(state["items"]), name, category, price, qty, day)
    state["items"].append(item)
    print(ui.green(f"  + Added #{item.id}: {item.name}, total {reports.money(item.total)}"))
    show_warnings(state, just_added=item)


def view_items(state):
    print()
    ordered = sorted(state["items"], key=lambda i: (i.date, i.id))
    ui.print_table(ordered)


def search_items(state):
    print("\nSearch (leave a field empty to skip it)")
    keyword = input("Keyword in name: ").strip()
    print("  Categories: " + ", ".join(CATEGORIES))
    category = ui.ask("Category", parse_category, allow_blank=True)
    hits = logic.search(state["items"], keyword, category)
    print(f"\n{len(hits)} match(es), total {reports.money(logic.total_spent(hits))}")
    ui.print_table(hits)


def delete_item(state):
    if not state["items"]:
        print(ui.dim("  nothing to delete"))
        return
    def parse_id(raw):
        try:
            return int(raw)
        except ValueError:
            raise BadValue("enter the numeric ID shown in the table")
    wanted = ui.ask("ID to delete (empty to cancel)", parse_id, allow_blank=True)
    if wanted is None:
        return
    match = next((i for i in state["items"] if i.id == wanted), None)
    if match is None:
        print(ui.red(f"  x no item with ID {wanted}"))
        return
    print(f"  {match.name}, {match.quantity} x {match.price:.2f} on {match.date}")
    if ui.confirm("Delete this item?"):
        state["items"].remove(match)
        print(ui.green("  - Deleted."))


def set_budget(state):
    print(f"\nCurrent budget: {reports.money(state['budget'])}")
    state["budget"] = ui.ask("New budget", parse_budget)
    print(ui.green(f"  Budget is now {reports.money(state['budget'])}"))
    show_warnings(state)


def show_summary(state):
    print()
    print(reports.summary_text(state))
    print()
    show_warnings(state)


def make_charts(state):
    try:
        paths = charts.make_charts(state, REPORT_DIR)
    except RuntimeError as err:
        print(ui.red(f"  x {err}"))
        return
    print(ui.green("  Charts saved:"))
    for p in paths:
        print("   ", os.path.relpath(p, ROOT))


def export_reports(state):
    paths = reports.export_all(state, REPORT_DIR)
    print(ui.green("  Reports saved:"))
    for p in paths:
        print("   ", os.path.relpath(p, ROOT))


def import_file(state):
    path = input("Path to CSV file (empty to cancel): ").strip().strip('"')
    if not path:
        return
    new_items, errors = importer.import_csv(path, state["items"])
    state["items"].extend(new_items)
    print(ui.green(f"  Imported {len(new_items)} row(s)."))
    if errors:
        log = importer.write_error_log(errors, path, REPORT_DIR)
        print(ui.yellow(f"  {len(errors)} row(s) rejected. Details in {os.path.relpath(log, ROOT)}:"))
        for e in errors[:5]:
            print("    " + e)
        if len(errors) > 5:
            print(f"    ...and {len(errors) - 5} more")
    show_warnings(state)


def load_sample(state):
    if state["items"] and not ui.confirm("This replaces your current data. Continue?"):
        return
    sample, notes = storage.load_state(SAMPLE_FILE)
    if not sample["items"]:
        print(ui.red("  x sample file is missing or empty"))
        return
    state["budget"], state["items"] = sample["budget"], sample["items"]
    print(ui.green(f"  Loaded {len(state['items'])} sample items."))
    show_warnings(state)


ACTIONS = {
    "1": add_item, "2": view_items, "3": search_items, "4": delete_item,
    "5": set_budget, "6": show_summary, "7": make_charts, "8": export_reports,
    "9": import_file, "10": load_sample,
}


def main():
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    state, notes = storage.load_state(DATA_FILE)
    ui.banner()
    for n in notes:
        print(ui.yellow("  note: " + n))
    if state["items"]:
        print(f"\nWelcome back. {len(state['items'])} items loaded.")
        show_warnings(state)
    else:
        print("\nNo saved items yet. Add one, or pick option 10 to try the sample data.")

    valid = set(ACTIONS) | {"0"}
    try:
        while True:
            ui.print_menu(current_budget_line(state))
            choice = ui.ask_menu_choice(valid)
            if choice == "0":
                break
            ACTIONS[choice](state)
            storage.save_state(state, DATA_FILE)  # save after every change
    except (KeyboardInterrupt, EOFError):
        print("\n  Interrupted, saving what you have.")

    storage.save_state(state, DATA_FILE)
    print("Saved. See you next time.")


if __name__ == "__main__":
    sys.exit(main())
