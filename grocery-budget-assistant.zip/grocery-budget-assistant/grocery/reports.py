"""Building the summary and exporting it as text, Markdown or CSV."""
import csv
import os
from datetime import datetime

from . import logic

CURRENCY = "Rs."


def money(x):
    return f"{CURRENCY} {x:,.2f}"


def summary_data(state):
    items, budget = state["items"], state["budget"]
    return {
        "budget": budget,
        "spent": logic.total_spent(items),
        "left": logic.remaining(budget, items),
        "percent": logic.percent_used(budget, items),
        "status": logic.status(budget, items),
        "count": len(items),
        "average": logic.average_item_cost(items),
        "categories": logic.by_category(items),
        "months": logic.by_month(items),
        "top": logic.priciest(items),
        "breach": logic.breach_date(budget, items),
        "anomalies": logic.find_anomalies(items, budget),
    }


def summary_text(state):
    s = summary_data(state)
    lines = [
        "GROCERY BUDGET SUMMARY",
        "=" * 40,
        f"Budget         : {money(s['budget'])}",
        f"Spent          : {money(s['spent'])} ({s['percent']}% of budget)",
        f"Remaining      : {money(s['left'])}",
        f"Status         : {s['status']}",
        f"Items logged   : {s['count']}",
        f"Average item   : {money(s['average'])}",
    ]
    if s["breach"]:
        lines.append(f"Budget crossed : on {s['breach']}")
    if s["categories"]:
        lines += ["", "Spending by category:"]
        for cat, val in s["categories"].items():
            share = val / s["spent"] * 100 if s["spent"] else 0
            lines.append(f"  {cat:<10} {money(val):>16}  {share:5.1f}%")
    if s["months"]:
        lines += ["", "Spending by month:"]
        for month, val in s["months"].items():
            lines.append(f"  {month}   {money(val):>16}")
    if s["top"]:
        lines += ["", "Biggest purchases:"]
        for i in s["top"]:
            lines.append(f"  {i.name} ({i.quantity} x {i.price:.2f}) = {money(i.total)}")
    if s["anomalies"]:
        lines += ["", "Things worth a second look:"]
        for item, why in s["anomalies"]:
            lines.append(f"  #{item.id} {item.name}: {why}")
    return "\n".join(lines)


def summary_markdown(state):
    s = summary_data(state)
    out = [
        "# Grocery Budget Report",
        f"_Generated {datetime.now():%Y-%m-%d %H:%M}_",
        "",
        f"- **Budget:** {money(s['budget'])}",
        f"- **Spent:** {money(s['spent'])} ({s['percent']}%)",
        f"- **Remaining:** {money(s['left'])}",
        f"- **Status:** {s['status']}",
        f"- **Items:** {s['count']} (average {money(s['average'])})",
        "",
    ]
    if s["categories"]:
        out += ["## By category", "", "| Category | Total |", "|---|---:|"]
        out += [f"| {c} | {money(v)} |" for c, v in s["categories"].items()]
        out.append("")
    if s["top"]:
        out += ["## Biggest purchases", ""]
        out += [f"1. {i.name}: {i.quantity} x {i.price:.2f} = {money(i.total)}" for i in s["top"]]
        out.append("")
    if s["anomalies"]:
        out += ["## Flags", ""]
        out += [f"- #{i.id} **{i.name}**: {why}" for i, why in s["anomalies"]]
        out.append("")
    return "\n".join(out)


def _stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def export_all(state, folder):
    """Write .txt, .md and .csv reports. Returns the list of file paths."""
    os.makedirs(folder, exist_ok=True)
    stamp = _stamp()
    paths = []

    txt = os.path.join(folder, f"summary-{stamp}.txt")
    with open(txt, "w", encoding="utf-8") as f:
        f.write(summary_text(state) + "\n")
    paths.append(txt)

    md = os.path.join(folder, f"summary-{stamp}.md")
    with open(md, "w", encoding="utf-8") as f:
        f.write(summary_markdown(state) + "\n")
    paths.append(md)

    csv_path = os.path.join(folder, f"items-{stamp}.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "name", "category", "price", "quantity", "total", "date"])
        for i in state["items"]:
            w.writerow([i.id, i.name, i.category, f"{i.price:.2f}", i.quantity, f"{i.total:.2f}", i.date])
    paths.append(csv_path)

    return paths
