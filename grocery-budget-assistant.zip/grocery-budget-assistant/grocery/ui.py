"""Everything that prints to the screen or reads from the keyboard."""
import sys

from .reports import money
from .validation import BadValue

USE_COLOR = sys.stdout.isatty()


def paint(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def green(t): return paint(t, "32")
def yellow(t): return paint(t, "33")
def red(t): return paint(t, "31")
def bold(t): return paint(t, "1")
def dim(t): return paint(t, "2")


STATUS_COLOR = {"ON TRACK": green, "WARNING": yellow, "OVER BUDGET": red, "NO BUDGET": dim}


def colored_status(label):
    return STATUS_COLOR.get(label, str)(label)


def banner():
    print()
    print(bold("=" * 44))
    print(bold("   GROCERY BUDGET ASSISTANT"))
    print("   Track what you buy. Stay under budget.")
    print(bold("=" * 44))


def ask(prompt, parser, allow_blank=False, default=None):
    """Keep asking until parser accepts the answer. Blank returns None if allow_blank."""
    while True:
        suffix = f" [{default}]" if default is not None else ""
        raw = input(f"{prompt}{suffix}: ").strip()
        if not raw:
            if default is not None:
                raw = str(default)
            elif allow_blank:
                return None
        try:
            return parser(raw)
        except BadValue as err:
            print(red(f"  x {err}"))


def confirm(question):
    while True:
        answer = input(f"{question} (y/n): ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print(red("  x please type y or n"))


def ask_menu_choice(valid):
    while True:
        raw = input("\nChoose an option: ").strip()
        if raw in valid:
            return raw
        print(red("  x that isn't on the menu"))


def print_menu(budget_line):
    print()
    print(budget_line)
    print("-" * 44)
    options = [
        "1  Add an item",
        "2  View all items",
        "3  Search / filter",
        "4  Delete an item",
        "5  Set budget",
        "6  Summary & warnings",
        "7  Make charts (PNG)",
        "8  Export reports",
        "9  Import a CSV file",
        "10 Load sample data",
        "0  Save and exit",
    ]
    for o in options:
        print("  " + o)


def print_table(items, page_size=15):
    if not items:
        print(dim("  (nothing to show)"))
        return
    header = f"{'ID':>4}  {'Name':<24} {'Category':<10} {'Price':>9} {'Qty':>4} {'Total':>10}  {'Date':<10}"
    for start in range(0, len(items), page_size):
        chunk = items[start:start + page_size]
        print(bold(header))
        print("-" * len(header))
        for i in chunk:
            name = i.name if len(i.name) <= 24 else i.name[:21] + "..."
            print(f"{i.id:>4}  {name:<24} {i.category:<10} {i.price:>9.2f} {i.quantity:>4} {i.total:>10.2f}  {i.date:<10}")
        shown = min(start + page_size, len(items))
        print(dim(f"  showing {shown} of {len(items)}"))
        if shown < len(items):
            if input("  Enter for next page, q to stop: ").strip().lower() == "q":
                break


def budget_line(state, status_label, spent, percent):
    return f"Budget {money(state['budget'])} | Spent {money(spent)} ({percent}%) | {colored_status(status_label)}"
