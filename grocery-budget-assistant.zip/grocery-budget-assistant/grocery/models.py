from dataclasses import dataclass, asdict


@dataclass
class Item:
    id: int
    name: str
    category: str
    price: float      # price of a single unit
    quantity: int
    date: str         # stored as YYYY-MM-DD

    @property
    def total(self):
        return round(self.price * self.quantity, 2)

    def to_dict(self):
        return asdict(self)
