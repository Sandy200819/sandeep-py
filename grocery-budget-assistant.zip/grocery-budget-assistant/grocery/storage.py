"""Saving and loading the app state as JSON."""
import json
import os
import shutil
from datetime import datetime

from .models import Item
from .validation import BadValue, parse_budget, parse_category, parse_date, parse_name, parse_price, parse_quantity

DEFAULT_BUDGET = 500.0


def fresh_state():
    return {"budget": DEFAULT_BUDGET, "items": []}


def _row_to_item(row):
    """Turn a stored dict back into an Item, re-checking every field."""
    return Item(
        id=int(row["id"]),
        name=parse_name(row["name"]),
        category=parse_category(row["category"]),
        price=parse_price(row["price"]),
        quantity=parse_quantity(row["quantity"]),
        date=parse_date(row["date"]),
    )


def load_state(path):
    """Read the data file. Never crashes: a missing or broken file gives a clean state.

    Returns (state, notes) where notes is a list of messages worth showing the user.
    """
    notes = []
    if not os.path.exists(path):
        return fresh_state(), notes

    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            raise ValueError("top level of the file is not an object")
    except (json.JSONDecodeError, ValueError, OSError) as err:
        backup = f"{path}.corrupt-{datetime.now():%Y%m%d-%H%M%S}"
        try:
            shutil.copy(path, backup)
            notes.append(f"Data file was unreadable ({err}). Copied it to {os.path.basename(backup)} and started fresh.")
        except OSError:
            notes.append(f"Data file was unreadable ({err}). Starting fresh.")
        return fresh_state(), notes

    try:
        budget = parse_budget(raw.get("budget", DEFAULT_BUDGET))
    except BadValue:
        budget = DEFAULT_BUDGET
        notes.append(f"Saved budget was invalid, reset to {DEFAULT_BUDGET:.0f}.")

    items, skipped, seen_ids = [], 0, set()
    rows = raw.get("items", [])
    if not isinstance(rows, list):
        rows = []
    for row in rows:
        try:
            item = _row_to_item(row)
        except (BadValue, KeyError, TypeError, ValueError):
            skipped += 1
            continue
        if item.id in seen_ids:
            skipped += 1
            continue
        seen_ids.add(item.id)
        items.append(item)
    if skipped:
        notes.append(f"Skipped {skipped} bad record(s) while loading.")

    return {"budget": budget, "items": items}, notes


def save_state(state, path):
    """Write to a temp file first so a crash mid-save can't wipe the real file."""
    payload = {
        "budget": state["budget"],
        "items": [item.to_dict() for item in state["items"]],
    }
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    os.replace(tmp, path)


def next_id(items):
    return max((i.id for i in items), default=0) + 1
