"""Bring in an old CSV file, checking every row and logging the ones that fail."""
import csv
import os
from datetime import datetime

from .models import Item
from .storage import next_id
from .validation import BadValue, parse_category, parse_date, parse_name, parse_price, parse_quantity

REQUIRED = ["name", "category", "price", "quantity", "date"]


def import_csv(path, existing_items):
    """Returns (new_items, errors). errors is a list of 'line N: reason' strings."""
    new_items, errors = [], []
    try:
        f = open(path, "r", newline="", encoding="utf-8-sig")
    except OSError as err:
        return [], [f"could not open file: {err.strerror or err}"]

    with f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            return [], ["file is empty"]
        headers = {h.strip().lower(): h for h in reader.fieldnames if h}
        missing = [c for c in REQUIRED if c not in headers]
        if missing:
            return [], ["missing column(s): " + ", ".join(missing)]

        everything = list(existing_items)
        for row in reader:
            line = reader.line_num
            try:
                get = lambda col: row.get(headers[col]) or ""
                item = Item(
                    id=next_id(everything),
                    name=parse_name(get("name")),
                    category=parse_category(get("category")),
                    price=parse_price(get("price")),
                    quantity=parse_quantity(get("quantity")),
                    date=parse_date(get("date")),
                )
            except BadValue as err:
                errors.append(f"line {line}: {err}")
                continue
            everything.append(item)
            new_items.append(item)

    return new_items, errors


def write_error_log(errors, source_path, folder):
    os.makedirs(folder, exist_ok=True)
    log_path = os.path.join(folder, "import_errors.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {source_path}\n")
        for e in errors:
            f.write(f"  {e}\n")
    return log_path
