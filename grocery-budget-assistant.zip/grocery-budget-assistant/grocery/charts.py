"""Charts with matplotlib. If matplotlib isn't installed the app keeps working without them."""
import os
from datetime import datetime

from . import logic

try:
    import matplotlib
    matplotlib.use("Agg")  # draw to files, no window needed
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except ImportError:
    HAVE_MPL = False


def make_charts(state, folder):
    """Save a category chart and a spending-trend chart. Returns a list of file paths."""
    if not HAVE_MPL:
        raise RuntimeError("matplotlib is not installed. Run: pip install matplotlib")
    items, budget = state["items"], state["budget"]
    if not items:
        raise RuntimeError("no items yet, so there is nothing to plot")

    os.makedirs(folder, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    paths = []

    # chart 1: where the money went
    cats = logic.by_category(items)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(list(cats.keys()), list(cats.values()), color="#4c9f70")
    ax.set_title("Spending by category")
    ax.set_ylabel("Amount spent")
    ax.bar_label(bars, fmt="%.0f", fontsize=8)
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    p1 = os.path.join(folder, f"categories-{stamp}.png")
    fig.savefig(p1, dpi=130)
    plt.close(fig)
    paths.append(p1)

    # chart 2: running total against the budget line
    running = logic.cumulative(items)
    days = [d for d, _ in running]
    totals = [t for _, t in running]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(days, totals, marker="o", markersize=3, color="#2b6cb0", label="Running total")
    ax.axhline(budget, color="#c53030", linestyle="--", label=f"Budget ({budget:,.0f})")
    ax.axhline(budget * logic.WARN_AT, color="#dd6b20", linestyle=":", label="80% warning line")
    ax.set_title("Cumulative spending vs budget")
    ax.set_ylabel("Amount spent")
    step = max(1, len(days) // 8)
    ax.set_xticks(days[::step])
    plt.setp(ax.get_xticklabels(), rotation=40, ha="right", fontsize=8)
    ax.legend()
    fig.tight_layout()
    p2 = os.path.join(folder, f"trend-{stamp}.png")
    fig.savefig(p2, dpi=130)
    plt.close(fig)
    paths.append(p2)

    return paths
