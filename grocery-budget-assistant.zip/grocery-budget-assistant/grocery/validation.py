"""All the checks for user input live here.

The parse_* functions are plain functions that either return a clean value
or raise BadValue. The terminal prompts and the CSV importer both use them,
so a value is judged the same way no matter where it came from.
"""
import math
import re
from datetime import date, datetime

CATEGORIES = [
    "produce", "dairy", "meat", "bakery", "pantry",
    "snacks", "drinks", "frozen", "household", "other",
]

MAX_PRICE = 10_000
MAX_QTY = 500
MAX_BUDGET = 1_000_000
NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .,'&%()/-]{0,59}$")


class BadValue(ValueError):
    """Raised when a value fails validation. The message is safe to show the user."""


def parse_name(raw):
    name = " ".join(str(raw).split())  # trims and collapses repeated spaces
    if not name:
        raise BadValue("name can't be empty")
    if not NAME_PATTERN.match(name):
        raise BadValue("name must be 1-60 characters (letters, numbers and basic punctuation)")
    return name[0].upper() + name[1:]


def parse_category(raw):
    cat = str(raw).strip().lower()
    if cat not in CATEGORIES:
        raise BadValue("category must be one of: " + ", ".join(CATEGORIES))
    return cat


def _to_number(raw, label):
    text = str(raw).strip().replace(",", "")
    for symbol in ("Rs.", "Rs", "$", "₹"):
        text = text.replace(symbol, "")
    text = text.strip()
    if not text:
        raise BadValue(f"{label} can't be blank")
    try:
        value = float(text)
    except ValueError:
        raise BadValue(f"'{raw}' is not a valid number")
    if not math.isfinite(value):
        raise BadValue(f"'{raw}' is not a valid number")
    return value


def parse_price(raw):
    value = _to_number(raw, "price")
    if value <= 0:
        raise BadValue("price must be more than 0")
    if value > MAX_PRICE:
        raise BadValue(f"price looks too high (limit is {MAX_PRICE:,})")
    return round(value, 2)


def parse_budget(raw):
    value = _to_number(raw, "budget")
    if value <= 0:
        raise BadValue("budget must be more than 0")
    if value > MAX_BUDGET:
        raise BadValue(f"budget is above the limit of {MAX_BUDGET:,}")
    return round(value, 2)


def parse_quantity(raw):
    text = str(raw).strip()
    if not text:
        raise BadValue("quantity can't be blank")
    try:
        qty = int(text)
    except ValueError:
        raise BadValue(f"'{raw}' is not a whole number")
    if qty < 1:
        raise BadValue("quantity must be at least 1")
    if qty > MAX_QTY:
        raise BadValue(f"quantity can't be more than {MAX_QTY}")
    return qty


def parse_date(raw):
    text = str(raw).strip()
    if not text:
        raise BadValue("date can't be blank")
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        raise BadValue("date must look like YYYY-MM-DD, e.g. 2026-03-14")
    if parsed > date.today():
        raise BadValue("date can't be in the future")
    if parsed.year < 2000:
        raise BadValue("date is too far in the past")
    return parsed.isoformat()
