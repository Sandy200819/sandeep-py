"""Grocery Budget Assistant - a small terminal app for tracking grocery spending."""
