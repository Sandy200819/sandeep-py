"""The actual budget maths. No printing and no input in here, which keeps it easy to test."""
from collections import defaultdict
from statistics import mean

WARN_AT = 0.80            # warn once 80% of the budget is gone
BIG_ITEM_SHARE = 0.20     # one line item above 20% of the budget looks odd
PRICE_SPIKE = 3.0         # unit price this many times its category average is suspicious


def total_spent(items):
    return round(sum(i.total for i in items), 2)


def remaining(budget, items):
    return round(budget - total_spent(items), 2)


def status(budget, items):
    spent = total_spent(items)
    if budget <= 0:
        return "NO BUDGET"
    if spent > budget:
        return "OVER BUDGET"
    if spent >= budget * WARN_AT:
        return "WARNING"
    return "ON TRACK"


def percent_used(budget, items):
    if budget <= 0:
        return 0.0
    return round(total_spent(items) / budget * 100, 1)


def by_category(items):
    totals = defaultdict(float)
    for i in items:
        totals[i.category] += i.total
    ordered = sorted(totals.items(), key=lambda pair: pair[1], reverse=True)
    return {cat: round(val, 2) for cat, val in ordered}


def by_day(items):
    totals = defaultdict(float)
    for i in items:
        totals[i.date] += i.total
    return {d: round(totals[d], 2) for d in sorted(totals)}


def by_month(items):
    totals = defaultdict(float)
    for i in items:
        totals[i.date[:7]] += i.total
    return {m: round(totals[m], 2) for m in sorted(totals)}


def cumulative(items):
    """Running total per day, oldest first. Returns a list of (date, running_total)."""
    running, out = 0.0, []
    for day, amount in by_day(items).items():
        running += amount
        out.append((day, round(running, 2)))
    return out


def breach_date(budget, items):
    """First day the running total went past the budget, or None."""
    for day, running in cumulative(items):
        if running > budget:
            return day
    return None


def average_item_cost(items):
    if not items:
        return 0.0
    return round(mean(i.total for i in items), 2)


def priciest(items, n=3):
    return sorted(items, key=lambda i: i.total, reverse=True)[:n]


def search(items, keyword="", category=None):
    keyword = keyword.strip().lower()
    hits = []
    for i in items:
        if category and i.category != category:
            continue
        if keyword and keyword not in i.name.lower():
            continue
        hits.append(i)
    return hits


def find_anomalies(items, budget):
    """Flag entries that look unusual. Returns a list of (item, reason)."""
    flagged = []

    cat_prices = defaultdict(list)
    for i in items:
        cat_prices[i.category].append(i)

    for i in items:
        reasons = []
        if budget > 0 and i.total > budget * BIG_ITEM_SHARE:
            reasons.append(f"single line is {i.total / budget * 100:.0f}% of the budget")
        peers = [p for p in cat_prices[i.category] if p.id != i.id]
        if len(peers) >= 3:
            avg = mean(p.price for p in peers)
            if avg > 0 and i.price > avg * PRICE_SPIKE:
                reasons.append(f"unit price is {i.price / avg:.1f}x the {i.category} average")
        if reasons:
            flagged.append((i, "; ".join(reasons)))
    return flagged
