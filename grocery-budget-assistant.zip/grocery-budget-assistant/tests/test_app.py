import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from grocery import importer, logic, storage
from grocery.models import Item
from grocery.validation import (
    BadValue, parse_date, parse_name, parse_price, parse_quantity, parse_category,
)


def make(id_, name, cat, price, qty, day="2026-10-01"):
    return Item(id_, name, cat, price, qty, day)


class ValidationTests(unittest.TestCase):
    def test_price_ok(self):
        self.assertEqual(parse_price("Rs. 1,250.5"), 1250.5)

    def test_price_bad(self):
        for bad in ["", "abc", "0", "-3", "nan", "inf", "99999"]:
            with self.assertRaises(BadValue):
                parse_price(bad)

    def test_quantity(self):
        self.assertEqual(parse_quantity(" 3 "), 3)
        for bad in ["2.5", "0", "-1", "", "x", "9999"]:
            with self.assertRaises(BadValue):
                parse_quantity(bad)

    def test_date(self):
        self.assertEqual(parse_date("2026-01-05"), "2026-01-05")
        for bad in ["05/01/2026", "2026-13-01", "", "2999-01-01"]:
            with self.assertRaises(BadValue):
                parse_date(bad)

    def test_name_and_category(self):
        self.assertEqual(parse_name("  basmati   rice "), "Basmati rice")
        with self.assertRaises(BadValue):
            parse_name("   ")
        with self.assertRaises(BadValue):
            parse_category("gadgets")


class LogicTests(unittest.TestCase):
    def setUp(self):
        self.items = [
            make(1, "Milk", "dairy", 60, 2, "2026-10-01"),
            make(2, "Rice", "pantry", 500, 1, "2026-10-02"),
            make(3, "Curd", "dairy", 40, 1, "2026-10-03"),
        ]

    def test_totals(self):
        self.assertEqual(logic.total_spent(self.items), 660)
        self.assertEqual(logic.remaining(1000, self.items), 340)

    def test_status_thresholds(self):
        self.assertEqual(logic.status(1000, self.items), "ON TRACK")
        self.assertEqual(logic.status(800, self.items), "WARNING")
        self.assertEqual(logic.status(600, self.items), "OVER BUDGET")

    def test_exactly_at_budget_is_not_over(self):
        self.assertEqual(logic.status(660, self.items), "WARNING")

    def test_category_totals(self):
        self.assertEqual(logic.by_category(self.items), {"pantry": 500, "dairy": 160})

    def test_breach_date(self):
        self.assertEqual(logic.breach_date(600, self.items), "2026-10-02")
        self.assertIsNone(logic.breach_date(1000, self.items))

    def test_search(self):
        self.assertEqual(len(logic.search(self.items, "mil")), 1)
        self.assertEqual(len(logic.search(self.items, "", "dairy")), 2)

    def test_big_item_flagged(self):
        flagged = logic.find_anomalies(self.items, 1000)
        self.assertEqual([i.name for i, _ in flagged], ["Rice"])

    def test_empty_list(self):
        self.assertEqual(logic.average_item_cost([]), 0.0)
        self.assertEqual(logic.status(100, []), "ON TRACK")


class StorageTests(unittest.TestCase):
    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "data.json")
            state = {"budget": 250.0, "items": [make(1, "Milk", "dairy", 60, 2)]}
            storage.save_state(state, path)
            loaded, notes = storage.load_state(path)
            self.assertEqual(loaded["budget"], 250.0)
            self.assertEqual(loaded["items"][0].name, "Milk")
            self.assertEqual(notes, [])

    def test_missing_file(self):
        state, _ = storage.load_state("/nonexistent/path/data.json")
        self.assertEqual(state["items"], [])

    def test_corrupt_file_is_backed_up(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "data.json")
            with open(path, "w") as f:
                f.write("{ not json")
            state, notes = storage.load_state(path)
            self.assertEqual(state["items"], [])
            self.assertTrue(notes)
            self.assertTrue(any(n.startswith("data.json.corrupt") for n in os.listdir(d)))

    def test_bad_records_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "data.json")
            with open(path, "w") as f:
                f.write('{"budget": 100, "items": [{"id": 1, "name": "Ok", "category": "dairy", '
                        '"price": 5, "quantity": 1, "date": "2026-01-01"}, {"id": 2}]}')
            state, notes = storage.load_state(path)
            self.assertEqual(len(state["items"]), 1)
            self.assertIn("Skipped 1", notes[0])


class ImporterTests(unittest.TestCase):
    def test_bad_rows_logged(self):
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        items, errors = importer.import_csv(os.path.join(here, "data", "bad_import.csv"), [])
        self.assertEqual([i.name for i in items], ["Mangoes", "Cashews 250g"])
        self.assertEqual(len(errors), 6)
        self.assertTrue(errors[0].startswith("line 3"))

    def test_missing_file(self):
        items, errors = importer.import_csv("/no/such/file.csv", [])
        self.assertEqual(items, [])
        self.assertEqual(len(errors), 1)


if __name__ == "__main__":
    unittest.main()
